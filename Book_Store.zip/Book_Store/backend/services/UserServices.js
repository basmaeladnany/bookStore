const User= require('../models/User')
var bcrypt = require("bcrypt")

// Ajouter un User 
const addUser = async(u)=>{
    const salt = await bcrypt.genSalt()
    u.password= await bcrypt.hash(u.password,salt)
   return await User.create(u)
} 

const getUsers=async()=>{
   return await User.find()
}



 // On va exporter les variables pour les importer dans le contrôleur
module.exports={
    getUsers,
    addUser,  
}