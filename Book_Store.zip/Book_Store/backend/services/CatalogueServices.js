const Book=require("../models/Book")
const Category=require("../models/Category")

const getAllBooks=async()=>{
    return await Book.find().populate("category")
 }
 
 const getBookById=async(id)=>{
     return await Book.findOne({_id: id})  
 }
 
 const deleteBookById=async(id)=>{
     return await Book.findByIdAndDelete({_id:id})   
 }
  
 const addBook = async(b)=>{
    return await Book.create(b)
 }

 const updateBook=async(book)=>{
     return await Book.findByIdAndUpdate(book._id, book)
 }

 const getAllCategories=async()=>{
    return await Category.find()
 }
 
 const getCategoryById=async(id)=>{
     return await Category.findOne({_id: id})  
 }
 
 const deleteCategoryById=async(id)=>{
     return await Category.findByIdAndDelete({_id:id})   
 }
  
 const addCategory = async(c)=>{
    return await Category.create(c)
 }

 const updateCategory=async(Category)=>{
     return await Category.findByIdAndUpdate(category._id, category)
 }
 module.exports={
   getAllBooks,
   getBookById,
   deleteBookById,
   addBook,
   updateBook,
   getAllCategories,
   getCategoryById,
   deleteCategoryById,
   addCategory,
   updateCategory
}