const express = require ("express")
const router = express.Router()
const CategoryController=require("../controllers/CatalogueController")


router.route("/").get(CategoryController.getAllCategories).post(CategoryController.createCategory)
router.get("/:id",CategoryController.getCategoryById)
router.delete("/:id",CategoryController.deleteCategory)
router.put("/:id",CategoryController.updateCategory)

module.exports=router