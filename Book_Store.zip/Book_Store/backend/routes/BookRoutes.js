const express = require ("express")
const router = express.Router()
const BookController=require("../controllers/CatalogueController")


router.route("/").get(BookController.getAllBooks).post(BookController.createBook)
router.get("/:id",BookController.getBookById)
router.delete("/:id",BookController.deleteBook)
router.put("/:id",BookController.updateBook)

module.exports=router