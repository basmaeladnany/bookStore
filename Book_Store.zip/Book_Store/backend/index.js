const express = require("express");
const app = express();
const mongoose = require("mongoose");
const BookRoutes=require("./routes/BookRoutes")
const CategoryRoutes=require("./routes/CategoryRoutes")
const UserRoutes= require("./routes/UserRoutes")

const cors = require("cors")
app.use(express.urlencoded({extended:true}));

app.use(cors())
require("dotenv").config()
mongoose.connect(process.env.MONGO_URI)
.then(result=>app.listen(4455, ()=>console.log("Server is running")))
.catch((err)=>console.log(err))


app.use(express.json())
app.use("/books",BookRoutes)
app.use("/categories",CategoryRoutes)
app.use("/users", UserRoutes)



