const cataService=require('../services/CatalogueServices')

const getAllBooks = async(req,res)=>{
    try{
     const result = await cataService.getAllBooks()
     res.status(200).json(result)
    }catch(error){
     res.status(500).json(error)
    } 
 }
 
 const getBookById =async (req, res)=>{
     try{
         const result = await  cataService.getBookById(req.params.id)
         res.status(200).json(result)
        }catch(error){
         res.status(500).json(error)
        }
 }
 const deleteBook = async(req,res)=>{
     try{
          await  cataService.deleteBookById(req.params.id)
         res.status(200).json("Livre bien supprimé")
        }catch(error){
         res.status(500).json(error)
        }
 }
 
 const createBook =async(req, res)=>{
     try{
         await  cataService.addBook(req.body)
         res.status(200).json("Livre bien ajouté")
        }catch(error){
         res.status(500).json(error)
        } 
 }
 const updateBook =async(req, res)=>{
     try{
         const result = await  cataService.updateBook(req.body)
         res.status(200).json(result)
        }catch(error){
         res.status(500).json(error)
        }
 }

 //Category
 const getAllCategories = async(req,res)=>{
    try{
     const result = await cataService.getAllCategories()
     res.status(200).json(result)
    }catch(error){
     res.status(500).json(error)
    } 
 }
 
 const getCategoryById =async (req, res)=>{
     try{
         const result = await  cataService.getCategoryById(req.params.id)
         res.status(200).json(result)
        }catch(error){
         res.status(500).json(error)
        }
 }
 const deleteCategory = async(req,res)=>{
     try{
          await  cataService.deleteCategoryById(req.params.id)
         res.status(200).json("Catégorie bien supprimée")
        }catch(error){
         res.status(500).json(error)
        }
 }
 
 const createCategory =async(req, res)=>{
     try{
          await  cataService.addCategory(req.body)
         res.status(200).json("Catégorie bien ajoutée")
        }catch(error){
         res.status(500).json(error)
        }
   
 }
 const updateCategory =async(req, res)=>{
     try{
         const result = await  cataService.updateCategory(req.body)
         res.status(200).json(result)
        }catch(error){
         res.status(500).json(error)
        }
   
 }

 module.exports = {
    getAllBooks,
    getBookById,
    deleteBook,
    createBook, 
    updateBook,
    getAllCategories,
    getCategoryById,
    deleteCategory,
    createCategory,
    updateCategory   
}