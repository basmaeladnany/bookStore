const userService = require("../services/UserServices")

const createUser =async(req, res)=>{
    try{
      
        await  userService.addUser(req.body)
        res.status(200).json("Utilisateur bien ajouté")
       }catch(error){
        res.status(500).json(error)
       }
}
const getAllUsers = async(req,res)=>{
   try{
    const users= await userService.getUsers()
    res.status(200).json(users)
   }catch(error){
    res.status(500).json(error)
   } 
}







 // On va exporter les variables pour les importer dans le fichier des routes 
module.exports = {
    getAllUsers,
    createUser , 
}

