const mongoose = require("mongoose")
const BookSchema = new mongoose.Schema({
    nom:{type:String,required:true},
    description:{type:String,required:true},
    isbn:{type:String,required:true},
    auteur:{type:String,required:true},
    editeur:{type:String,required:true},
    date_edition:{type:Date,default:Date.now()},
    image:{type:String},
    category:{
        type:mongoose.Types.ObjectId,
        ref:"Category",
        required:true
    }
})

const Book = mongoose.model("Book",BookSchema )
module.exports = Book