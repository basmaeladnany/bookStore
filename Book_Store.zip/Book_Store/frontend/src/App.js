
import { Route, Routes } from 'react-router-dom';
import './App.css';
import AdminLayout from './components/Admin.layout';
import BookList from './components/BookList'
import BookNew from './components/BookNew'
import Home from './components/Home';
function App() {
  return (
   <>
       <Routes>
          <Route path={"/admin"} element={<AdminLayout/>}>
              <Route path={"books"} element={<BookList/>}/>
              <Route path={"books/new"} element={<BookNew/>}/>
          </Route>
          <Route path={"/"} element={<Home/>}>

          </Route>

       </Routes>
   </>
   
    
  );
}

export default App;
