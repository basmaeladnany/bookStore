function Home (){
    return(
        <h1>La page home</h1>
    )
}

export default Home