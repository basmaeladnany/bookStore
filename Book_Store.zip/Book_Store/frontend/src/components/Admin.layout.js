import { Outlet } from "react-router-dom"

function AdminLayout(){
    return(
        <div>
             <nav>
            <ul>
                <li>Accueil</li>
                <li>Livres</li>
                <li>Contact</li>
                <li>Connexion</li>
            </ul>
        </nav>
        <Outlet/>
        </div>
       
    )
}
export default AdminLayout