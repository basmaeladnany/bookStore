function BookNew(){
    return(
        <form>
          Formulaire  
        </form>
    )
}

export default BookNew